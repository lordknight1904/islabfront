import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom';
import Home from './Home/Home';
import Header from './Header/Header';
import CustomHelmet from './CustomHelmet/CustomHelmet';
import paths from './paths';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <CustomHelmet />
        <Header key="header" />
        <Switch key="switch">
          {
            paths.map((prop, key) => (
              <Route path={prop.url} exact={prop.exact} component={prop.component} key={key} />
            ))
          }
        </Switch>
      </div>
    );
  }
}

export default App;
