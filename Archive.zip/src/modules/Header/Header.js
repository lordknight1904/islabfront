import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Link, withRouter } from 'react-router-dom';
import MenuIcon from '@material-ui/icons/Menu';
import {
  withStyles,
  Menu,
  MenuItem,
  Button,
  Typography,
  Toolbar,
  AppBar,
  IconButton,
} from '@material-ui/core';
import { fetchTitle } from '../../reducers/App/app';
import headerStyle from '../../assets/jss/components/headerStyle';
import headers from '../../data/headers';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      anchorEl: null,
    };
  }

  handleClick = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleClose = () => {
    this.setState({ anchorEl: null });
  };

  render() {
    const { anchorEl } = this.state;
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        <AppBar position="static">
          <Toolbar>
            <IconButton className={classes.menuButton} color="inherit" aria-label="Menu">
              <MenuIcon />
            </IconButton>
            <Typography variant="title" color="inherit" className={classes.flex}>
              Islab
            </Typography>
            {
              headers.map((h, index) => (
                h.dropDown ? (
                  <div key={index}>
                    <Button
                      aria-owns={anchorEl ? 'simple-menu' : null}
                      aria-haspopup="true"
                      color="inherit"
                      onClick={this.handleClick}
                    >
                      {h.title}
                    </Button>
                    <Menu
                      id="simple-menu"
                      anchorEl={anchorEl}
                      open={Boolean(anchorEl)}
                      onClose={this.handleClose}
                    >
                      {
                        h.pages.map((p, index2) => (
                          <Link key={index2} to={p.url} className={classes.navLink}>
                            <MenuItem onClick={this.handleClose}>
                              {p.title}
                            </MenuItem>
                          </Link>
                        ))
                      }
                    </Menu>
                  </div>
                ) : (
                  <Link key={index} to={h.url} className={classes.navLink}>
                    <Button color="inherit">
                      {h.title}
                    </Button>
                  </Link>
                )
              ))
            }
          </Toolbar>
        </AppBar>
      </div>
    );
  }
}

Header.propTypes = {
  app: PropTypes.object.isRequired,
  location: PropTypes.object.isRequired,
};

const mapStateToProps = ({ app }) => ({
  app,
});
const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      fetchTitle,
    },
    dispatch,
  );
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(withStyles(headerStyle)(Header)));
